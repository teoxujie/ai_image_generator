Installation & Setup

Clone the repository:

bash
git clone https://gitlab.com/7719-st1516/ca2-daaa2b04-2317719-teoxujie.git

Create and activate virtual environment:

bash
python -m venv env
source ./env/Scripts/activate # Windows
source ./env/bin/activate # Unix/MacOS

Install dependencies:

bash

pip install -r requirements.txt


Run the application on docker:

docker build -t ai-letter-generator:latest .
docker run -d --name ai-letter-generator -p 5000:5000 -e FLASK_APP=run.py -e FLASK_ENV=development ai-letter-generator:latest

OR

bash
FLASK_APP=app.py python -m flask run


To run tests
cd tests
python -m pytest test_routes.py -v