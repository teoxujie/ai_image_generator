import pytest
import json
from datetime import datetime

# Helper function to login
def login(client):
    return client.post('/login', json={
        'username': 'testuser',
        'password': 'password123'
    })

class TestAuth:
    # Login Tests
    def test_valid_login(self, client):
        response = client.post('/login', json={
            'username': 'testuser',
            'password': 'password123'
        })
        assert response.status_code == 200
        assert 'message' in json.loads(response.data)

    def test_login_range(self, client):
        response = client.post('/login', json={
            'username': 'a' * 101,
            'password': 'b' * 101
        })
        assert response.status_code == 400

    def test_login_consistency(self, client):
        for _ in range(3):
            response = client.post('/login', json={
                'username': 'testuser',
                'password': 'password123'
            })
            assert response.status_code == 200

    def test_login_unexpected_failure(self, client):
        response = client.post('/login', data='invalid-json')
        assert response.status_code == 400

    def test_login_expected_failure(self, client):
        response = client.post('/login', json={
            'username': 'wrong',
            'password': 'wrong'
        })
        assert response.status_code == 401

    # Register Tests
    def test_valid_register(self, client):
        response = client.post('/register', json={
            'username': 'newuser',
            'email': 'new@example.com',
            'password': 'password123',
            'confirm_password': 'password123'
        })
        assert response.status_code == 201

    def test_register_range(self, client):
        response = client.post('/register', json={
            'username': 'a' * 101,
            'email': 'test@example.com',
            'password': 'password123',
            'confirm_password': 'password123'
        })
        assert response.status_code == 400

    def test_register_consistency(self, client):
        # First registration should succeed
        response1 = client.post('/register', json={
            'username': 'testuser1',
            'email': 'test1@example.com',
            'password': 'password123',
            'confirm_password': 'password123'
        })
        # Second with same username should fail
        response2 = client.post('/register', json={
            'username': 'testuser1',
            'email': 'test2@example.com',
            'password': 'password123',
            'confirm_password': 'password123'
        })
        assert response1.status_code == 201
        assert response2.status_code == 400

    def test_register_unexpected_failure(self, client):
        response = client.post('/register', data='invalid-json')
        assert response.status_code == 400

    def test_register_expected_failure(self, client):
        response = client.post('/register', json={
            'username': 'testuser',  # Existing username
            'email': 'test@example.com',
            'password': 'password123',
            'confirm_password': 'different123'
        })
        assert response.status_code == 400

    # Logout Test
    def test_logout(self, client):
        login(client)
        response = client.get('/logout')
        assert response.status_code in [200, 302]

class TestGeneration:
    def test_valid_generation(self, client):
        login(client)
        response = client.post('/generate', json={
            'mode': 'specific',
            'label': 'A',
            'n_samples': 1
        })
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'saved_images' in data

    def test_generation_range(self, client):
        login(client)
        test_cases = [
            {'n_samples': 0, 'expected_code': 400},
            {'n_samples': 51, 'expected_code': 400},
            {'n_samples': -1, 'expected_code': 400}
        ]
        for case in test_cases:
            response = client.post('/generate', json={
                'mode': 'specific',
                'label': 'A',
                'n_samples': case['n_samples']
            })
            assert response.status_code == case['expected_code']

    def test_generation_consistency(self, client):
        login(client)
        responses = []
        for _ in range(2):
            response = client.post('/generate', json={
                'mode': 'specific',
                'label': 'A',
                'n_samples': 1
            })
            responses.append(response.status_code)
        assert all(code == 200 for code in responses)

class TestHistory:
    def test_valid_history(self, client):
        login(client)
        response = client.get('/history')
        assert response.status_code == 200

    def test_history_range(self, client):
        login(client)
        response = client.get('/history?date=2024-01-01')
        assert response.status_code == 200
        response = client.get('/history?date=invalid')
        assert response.status_code == 400

    def test_history_consistency(self, client):
        login(client)
        response1 = client.get('/history')
        response2 = client.get('/history')
        assert response1.status_code == response2.status_code == 200

    def test_delete_history(self, client):
        login(client)
        # First generate an image
        client.post('/generate', json={
            'mode': 'specific',
            'label': 'A',
            'n_samples': 1
        })
        # Then delete it
        response = client.delete('/history/1')
        assert response.status_code == 200

    def test_delete_all_history(self, client):
        login(client)
        response = client.delete('/history')
        assert response.status_code == 200
