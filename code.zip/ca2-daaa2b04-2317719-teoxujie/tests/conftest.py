import os
import sys
import pytest

# Add the project root directory to Python path
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

from application import app, db
from application.models import User

@pytest.fixture(autouse=True)
def setup_database():
    """Setup and teardown the database for each test"""
    with app.app_context():
        db.drop_all()  # Drop all tables first
        db.create_all()  # Create fresh tables
    yield
    with app.app_context():
        db.session.remove()
        db.drop_all()  # Clean up after test

@pytest.fixture
def client():
    app.config.update({
        'TESTING': True,
        'SQLALCHEMY_DATABASE_URI': 'sqlite:///:memory:',
        'WTF_CSRF_ENABLED': False,
        'LOGIN_DISABLED': False,
        'SQLALCHEMY_ENGINE_OPTIONS': {}
    })
    
    with app.test_client() as client:
        with app.app_context():
            # Create test user
            user = User(username='testuser', email='test@example.com')
            user.set_password('password123')
            db.session.add(user)
            db.session.commit()
            
            # Set up test client session
            with client.session_transaction() as sess:
                sess['_user_id'] = str(user.id)
                sess['_fresh'] = True
            
            yield client

@pytest.fixture
def test_user():
    return User.query.filter_by(username='testuser').first()

@pytest.fixture
def auth_headers():
    return {
        'Authorization': 'Basic ' + 'testuser:password123'.encode('base64').decode('utf-8')
    }
