from dropbox import Dropbox
from dropbox.files import WriteMode
from datetime import datetime, timedelta
from application import app

class DropboxService:
    def __init__(self):
        self.app_key = app.config['DROPBOX_APP_KEY']
        self.app_secret = app.config['DROPBOX_APP_SECRET']
        self.refresh_token = app.config['DROPBOX_REFRESH_TOKEN']
        self.client = None
        self._refresh_access_token()

    def _refresh_access_token(self):
        """Get a new access token using the refresh token"""
        try:
            self.client = Dropbox(
                app_key=self.app_key,
                app_secret=self.app_secret,
                oauth2_refresh_token=self.refresh_token
            )
        except Exception as e:
            print(f"Error refreshing token: {e}")
            raise

    def upload_file(self, file_path, dropbox_path):
        """Upload file to Dropbox and return shareable link"""
        try:
            with open(file_path, 'rb') as f:
                self.client.files_upload(
                    f.read(),
                    dropbox_path,
                    mode=WriteMode.overwrite
                )
            
            # Create shareable link
            shared_link = self.client.sharing_create_shared_link(dropbox_path)
            return shared_link.url.replace('?dl=0', '?dl=1')  # Direct download link
            
        except Exception as e:
            print(f"Error uploading to Dropbox: {e}")
            # Try refreshing token and retry once
            self._refresh_access_token()
            try:
                with open(file_path, 'rb') as f:
                    self.client.files_upload(
                        f.read(),
                        dropbox_path,
                        mode=WriteMode.overwrite
                    )
                shared_link = self.client.sharing_create_shared_link(dropbox_path)
                return shared_link.url.replace('?dl=0', '?dl=1')
            except Exception as e:
                print(f"Error after token refresh: {e}")
                raise
