async function deleteItem(id) {
  if (!confirm('Are you sure you want to delete this item?')) {
      return;
  }

  try {
      const response = await fetch(`/history/${id}`, {
          method: 'DELETE',
          headers: {
              'Content-Type': 'application/json',
          }
      });

      if (response.ok) {
          const element = document.querySelector(`[data-id="${id}"]`);
          element.style.opacity = '0';
          setTimeout(() => {
              element.remove();
              // Check if no more images
              const grid = document.querySelector('.history-grid');
              if (!grid || grid.children.length === 0) {
                  window.location.reload();
              }
          }, 300);
      } else {
          const data = await response.json();
          alert(data.error || 'Failed to delete history item');
      }
  } catch (error) {
      console.error('Error:', error);
      alert('Failed to delete history item');
  }
}

document.addEventListener('DOMContentLoaded', function() {
  const deleteAllBtn = document.getElementById('deleteAllBtn');
  if (deleteAllBtn) {
      deleteAllBtn.addEventListener('click', async function() {
          if (!confirm('Are you sure you want to delete all images?')) return;
          
          try {
              const response = await fetch('/history', {
                  method: 'DELETE'
              });
              if (response.ok) {
                  location.reload();
              }
          } catch (error) {
              console.error('Error:', error);
          }
      });
  }
});
