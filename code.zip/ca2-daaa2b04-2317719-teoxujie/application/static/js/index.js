document.getElementById('mode').addEventListener('change', function() {
  const letterGroup = document.getElementById('letterGroup');
  letterGroup.style.display = this.value === 'specific' ? 'flex' : 'none';
});

document.getElementById('generateForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  
  const mode = document.getElementById('mode').value;
  const letter = document.getElementById('letter').value;
  const samples = parseInt(document.getElementById('samples').value);
  
  const loading = document.getElementById('loading');
  const results = document.getElementById('results');
  
  // Reset results and show loading
  results.innerHTML = '';
  loading.innerHTML = `
    <div class="spinner"></div>
    <p>Generating your letters... Please wait</p>
  `;
  loading.style.display = 'block';
  
  try {
      const response = await fetch('/generate', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json',
          },
          body: JSON.stringify({
              mode: mode,
              label: letter,
              n_samples: samples
          })
      });
      
      const data = await response.json();
      
      if (response.ok) {
          // Initialize progress display
          loading.innerHTML = `
              <div class="spinner"></div>
              <p>Generating images... <span id="progress">0</span>/<span id="total">${data.saved_images.length}</span></p>
          `;
          
          // Display images in chunks
          const CHUNK_SIZE = 5;
          const displayImages = (startIdx) => {
              const chunk = data.saved_images.slice(startIdx, startIdx + CHUNK_SIZE);
              const html = chunk.map(image => `
                  <div class="image-container">
                      <img src="/static/generated_images/${image}" 
                           alt="Generated Letter" 
                           class="generated-image"
                           loading="lazy">
                      <p class="letter-label">Letter: ${image.split('_')[0]}</p>
                      <a href="/static/generated_images/${image}" download class="download-btn">
                          <i class="fas fa-download"></i> Download
                      </a>
                  </div>
              `).join('');
              results.innerHTML += html;

              // Update progress
              const progress = document.getElementById('progress');
              const total = document.getElementById('total');
              if (progress && total) {
                  progress.textContent = Math.min(startIdx + CHUNK_SIZE, data.saved_images.length);
                  total.textContent = data.saved_images.length;
              }

              if (startIdx + CHUNK_SIZE < data.saved_images.length) {
                  setTimeout(() => displayImages(startIdx + CHUNK_SIZE), 500);
              } else {
                  loading.style.display = 'none';
              }
          };
          
          displayImages(0);
      } else {
          results.innerHTML = `<div class="error">${data.error}</div>`;
          loading.style.display = 'none';
      }
  } catch (error) {
      results.innerHTML = `<div class="error">An error occurred: ${error.message}</div>`;
      loading.style.display = 'none';
  }
});
