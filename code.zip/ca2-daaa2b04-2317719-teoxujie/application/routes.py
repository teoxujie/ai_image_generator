from flask import render_template, redirect, url_for, flash, request, jsonify, session
import json
import os
import numpy as np
import requests
from numpy.random import randn
from datetime import datetime, timedelta
from numpy import asarray
from PIL import Image
from application import app
from application.forms import LoginForm, RegistrationForm
import time
from flask_login import login_user, logout_user, login_required, current_user
from application.models import db, User, History
from application.services.dropbox_service import DropboxService
from werkzeug.utils import secure_filename

# Constants
GAN_URL = "https://ca2-daaa2b04-2317719-teoxujie.onrender.com/v1/models/img_generator:predict"
LABEL_MAP = {chr(i + 65): i for i in range(26)}  # {'A': 0, 'B': 1, ..., 'Z': 25}

# Initialize Dropbox service
dropbox_service = DropboxService()

def generate_latent_points(latent_dim, n_samples):
    x_input = randn(latent_dim * n_samples)
    z_input = x_input.reshape(n_samples, latent_dim)
    return z_input

# Add CORS and error handlers
@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization,X-Requested-With')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    response.headers.add('Access-Control-Allow-Credentials', 'true')
    response.headers.add('Access-Control-Expose-Headers', 'Content-Type,Authorization')
    return response

# Set-up route for home page
@app.route('/')
def index():
    return render_template("index.html", title="Home Page")

@app.route('/login', methods=['GET', 'POST', 'OPTIONS'])
def login():
    if request.method == 'OPTIONS':
        return '', 200
        
    if request.method == 'POST':
        # Check if Content-Type is missing or invalid
        content_type = request.headers.get('Content-Type', '')
        if content_type != 'application/json' and 'application/x-www-form-urlencoded' not in content_type:
            return jsonify({"error": "Invalid Content-Type"}), 400
            
        # Handle JSON requests
        if content_type == 'application/json':
            try:
                data = request.get_json()
                if data is None:
                    return jsonify({"error": "Invalid JSON format"}), 400
                    
                if not data or 'username' not in data or 'password' not in data:
                    return jsonify({"error": "Missing username or password"}), 400
                    
                if len(data['username']) > 80 or len(data['password']) > 100:
                    return jsonify({"error": "Username or password too long"}), 400
                
                user = User.query.filter_by(username=data.get('username')).first()
                if user and user.check_password(data.get('password')):
                    login_user(user)
                    return jsonify({
                        "message": "Login successful",
                        "user": {
                            "id": user.id,
                            "username": user.username,
                            "email": user.email
                        }
                    }), 200
                return jsonify({"error": "Invalid credentials"}), 401
            except (ValueError, TypeError, json.JSONDecodeError):
                return jsonify({"error": "Invalid JSON format"}), 400
            except Exception as e:
                app.logger.error(f"Login error: {str(e)}")
                return jsonify({"error": "An unexpected error occurred"}), 500
        else:
            # Handle form submission
            form = LoginForm()
            if form.validate_on_submit():
                user = User.query.filter_by(username=form.username.data).first()
                if user and user.check_password(form.password.data):
                    login_user(user)
                    return redirect(url_for('generate'))
                flash('Invalid username or password', 'error')
            return render_template('login.html', title='Login', form=form)
            
    return render_template('login.html', title='Login', form=LoginForm())

@app.route('/logout')
@login_required
def logout():
    logout_user()
    # Clear any existing flash messages
    session.pop('_flashes', None)
    return redirect(url_for('index'))

@app.route('/register', methods=['GET', 'POST', 'OPTIONS'])
def register():
    form = RegistrationForm()
    
    if request.method == 'OPTIONS':
        return '', 200

    if request.method == 'POST':
        # Check if Content-Type is missing or invalid
        content_type = request.headers.get('Content-Type', '')
        if content_type != 'application/json' and 'application/x-www-form-urlencoded' not in content_type:
            return jsonify({"error": "Invalid Content-Type"}), 400

        # Handle JSON requests
        if request.is_json:
            try:
                data = request.get_json()
                if data is None:
                    return jsonify({"error": "Invalid JSON format"}), 400
                
                # Validate JSON data
                if len(data.get('username', '')) > 100:
                    return jsonify({"error": "Username too long"}), 400
                
                # Check if username exists
                if User.query.filter_by(username=data.get('username')).first():
                    return jsonify({"error": "Username already exists"}), 400
                
                # Check if email exists
                if User.query.filter_by(email=data.get('email')).first():
                    return jsonify({"error": "Email already registered"}), 400
                
                # Check password match
                if data.get('password') != data.get('confirm_password'):
                    return jsonify({"error": "Passwords do not match"}), 400
                
                # Create new user
                user = User(
                    username=data.get('username'),
                    email=data.get('email')
                )
                user.set_password(data.get('password'))
                
                db.session.add(user)
                db.session.commit()
                login_user(user)
                
                return jsonify({"message": "Registration successful"}), 201
                
            except Exception as e:
                db.session.rollback()
                return jsonify({"error": "Invalid request data"}), 400
        
        try:
            # Handle form submission
            if form.validate_on_submit():
                try:
                    if User.query.filter_by(username=form.username.data).first():
                        flash('Username already exists. Please choose a different one.', 'error')
                        return render_template('register.html', form=form)

                    if User.query.filter_by(email=form.email.data).first():
                        flash('Email already registered. Please use a different one.', 'error')
                        return render_template('register.html', form=form)

                    user = User(username=form.username.data, email=form.email.data)
                    user.set_password(form.password.data)

                    db.session.add(user)
                    db.session.commit()
                    login_user(user)

                    flash('Registration successful!', 'success')
                    return redirect(url_for('generate'))
                except Exception as e:
                    db.session.rollback()
                    flash('An error occurred during registration. Please try again.', 'error')
                    app.logger.error(f'Registration error: {str(e)}')
                    return render_template('register.html', form=form)
            else:
                # If form validation fails, render template with errors
                for field, errors in form.errors.items():
                    for error in errors:
                        flash(f'{field}: {error}', 'error')
                return render_template('register.html', form=form)
        except Exception as e:
            return jsonify({"error": "Invalid request format"}), 400

    # GET request
    return render_template('register.html', title='Register', form=form)


@app.route('/generate', methods=['GET', 'POST'])
@login_required
def generate():
    if request.method == 'GET':
        if request.headers.get('Content-Type') == 'application/json':
            return jsonify({"message": "Generate page"}), 200
        return render_template('generate.html', title='Generate')
    
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "Missing request data"}), 400

        latent_dim = 100
        mode = data.get("mode")
        n_samples = data.get("n_samples")
        
        # Validate mode
        if not mode or mode not in ["specific", "random"]:
            return jsonify({"error": "Invalid mode. Must be 'specific' or 'random'"}), 400
            
        # Validate n_samples
        if not isinstance(n_samples, int) or n_samples <= 0 or n_samples > 50:
            return jsonify({"error": "Invalid n_samples. Must be between 1 and 50"}), 400
            
        # Validate label for specific mode
        if mode == "specific":
            label = data.get("label", "").upper()
            if not label or label not in LABEL_MAP:
                return jsonify({"error": "Invalid label. Must be A-Z"}), 400

        # Add randomization to ensure different results each time
        np.random.seed(None)

        # Process in batches of 50 to prevent memory issues
        BATCH_SIZE = 50
        saved_images = []
        static_img_path = os.path.join(app.static_folder, 'generated_images')
        os.makedirs(static_img_path, exist_ok=True)
        timestamp = int(time.time() * 1000)

        for batch_start in range(0, n_samples, BATCH_SIZE):
            batch_size = min(BATCH_SIZE, n_samples - batch_start)
            
            if mode == "random":
                # Generate random letters for this batch
                for _ in range(batch_size):
                    label_char = chr(np.random.randint(65, 91))
                    numeric_label = LABEL_MAP[label_char]
                    
                    latent_points = np.random.normal(0, 1, (1, latent_dim))
                    labels = asarray([numeric_label]).reshape(-1, 1)
                    
                    saved_images.extend(generate_single_image(
                        label_char, latent_points, labels, static_img_path, timestamp, batch_start
                    ))
            else:
                # Generate specific letter for this batch
                label_char = label
                if label_char not in LABEL_MAP:
                    return jsonify({"error": f"Invalid label '{label_char}'. Must be one of {list(LABEL_MAP.keys())}."}), 400
                
                numeric_label = LABEL_MAP[label_char]
                latent_points = np.random.normal(0, 1, (batch_size, latent_dim))
                labels = asarray([numeric_label] * batch_size).reshape(-1, 1)
                
                saved_images.extend(generate_single_image(
                    label_char, latent_points, labels, static_img_path, timestamp, batch_start
                ))

        return jsonify({
            "message": "Images generated successfully.",
            "count": len(saved_images),
            "saved_images": saved_images
        })

    except json.JSONDecodeError:
        return jsonify({"error": "Invalid JSON format"}), 400
    except requests.RequestException as e:
        app.logger.error(f"GAN API error: {str(e)}")
        return jsonify({"error": "Failed to generate image"}), 503
    except Exception as e:
        app.logger.error(f"Generation error: {str(e)}")
        return jsonify({"error": "An unexpected error occurred"}), 500

def generate_single_image(label_char, latent_points, labels, static_img_path, timestamp, start_idx=0):
    instances = [
        {"input_16": latent_points[i].tolist(), "input_15": labels[i].tolist()}
        for i in range(latent_points.shape[0])
    ]

    payload = json.dumps({
        "signature_name": "serving_default",
        "instances": instances
    })
    
    headers = {"content-type": "application/json"}
    saved_images = []

    try:
        response = requests.post(GAN_URL, data=payload, headers=headers)
        response.raise_for_status()
        predictions = response.json()["predictions"]

        for idx, pred in enumerate(predictions):
            img_array = np.array(pred).reshape(28, 28)
            img_array = (img_array + 1) / 2.0
            img = Image.fromarray((img_array * 255).astype(np.uint8))
            
            img_filename = f"{label_char}_{timestamp}_{start_idx + idx}.png"
            img_path = os.path.join(static_img_path, img_filename)
            img.save(img_path)
            
            cloud_url = None
            try:
                # Upload to Dropbox and get shareable link
                dropbox_path = f"/generated_letters/{img_filename}"
                cloud_url = dropbox_service.upload_file(img_path, dropbox_path)
            except Exception as e:
                print(f"Dropbox upload failed: {e}")
            
            # Always create history item with cloud_url (can be None)
            history_item = History(
                letter=label_char,
                filename=img_filename,
                user_id=current_user.id,
                cloud_url=cloud_url
            )
            db.session.add(history_item)
            saved_images.append(img_filename)
        
        db.session.commit()
        return saved_images

    except requests.exceptions.RequestException as e:
        print(f"Request Error: {e}")
        db.session.rollback()
        return []
    

from datetime import datetime


@app.route('/history')
@login_required
def history():
    try:
        letter_filter = request.args.get('letter', '').upper()
        date_filter = request.args.get('date', '')
        
        # Validate letter filter
        if letter_filter and letter_filter not in LABEL_MAP:
            return jsonify({"error": "Invalid letter filter"}), 400
            
        # Validate date filter
        if date_filter:
            try:
                date_obj = datetime.strptime(date_filter, '%Y-%m-%d')
            except ValueError:
                return jsonify({"error": "Invalid date format. Use YYYY-MM-DD"}), 400
        
        query = History.query.filter_by(user_id=current_user.id)
        
        if letter_filter:
            query = query.filter(History.letter == letter_filter)
        if date_filter:
            query = query.filter(
                History.created_at >= date_obj,
                History.created_at < date_obj + timedelta(days=1)
            )
        
        history_items = query.order_by(History.created_at.desc()).all()
        
        if request.headers.get('Content-Type') == 'application/json':
            return jsonify({
                "history": [item.to_dict() for item in history_items]
            }), 200
        return render_template('history.html', 
                            title="Generation History", 
                            history_items=history_items,
                            letters=list(LABEL_MAP.keys()))
    except Exception as e:
        app.logger.error(f"History error: {str(e)}")
        return jsonify({"error": "An unexpected error occurred"}), 500

@app.route('/history/<int:history_id>', methods=['DELETE'])
@login_required
def delete_history(history_id):
    try:
        if history_id < 1:
            return jsonify({"error": "Invalid history ID"}), 400
            
        history_item = History.query.get_or_404(history_id)
        
        if history_item.user_id != current_user.id:
            return jsonify({"error": "Unauthorized"}), 403
            
        if not history_item.filename:
            return jsonify({"error": "Invalid filename"}), 400
            
        image_path = os.path.join(app.static_folder, 'generated_images', 
                                 secure_filename(history_item.filename))
        
        if os.path.exists(image_path):
            try:
                os.remove(image_path)
            except OSError as e:
                app.logger.error(f"File deletion error: {str(e)}")
                return jsonify({"error": "Failed to delete file"}), 500
                
        db.session.delete(history_item)
        db.session.commit()
        
        return jsonify({"message": "Image deleted successfully"})
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Delete history error: {str(e)}")
        return jsonify({"error": "An unexpected error occurred"}), 500

@app.route('/history', methods=['DELETE'])
@login_required
def delete_all_history():
    try:
        history_items = History.query.filter_by(user_id=current_user.id).all()
        
        for item in history_items:
            image_path = os.path.join(app.static_folder, 'generated_images', 
                                    secure_filename(item.filename))
            if os.path.exists(image_path):
                try:
                    os.remove(image_path)
                except OSError as e:
                    app.logger.error(f"File deletion error: {str(e)}")
                    continue
        
        History.query.filter_by(user_id=current_user.id).delete()
        db.session.commit()
        
        return jsonify({"message": "All images deleted successfully"})
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Delete all history error: {str(e)}")
        return jsonify({"error": "An unexpected error occurred"}), 500
