from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

# Initialize Flask
app = Flask(__name__)

# Load config
app.config.from_pyfile('config.cfg')

# Set database URI and options
app.config['SQLALCHEMY_DATABASE_URI'] = "mysql://avnadmin:AVNS_7F-LU-NNalOc_P6jzz2@mysql-1a715ad0-ai-letter-generator.i.aivencloud.com:13187/defaultdb"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    "connect_args": {
        "ssl": {}
    }
}

# Initialize SQLAlchemy
db = SQLAlchemy(app)

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Import models and create tables
from application.models import User
with app.app_context():
    db.create_all()

# Import routes
from application import routes
